class Player:
    def __init__(self, name: str, color: int):
        self.__name = name
        self.__color = color

    def getName(self):
        return self.__name

    def getColor(self):
        return self.__color

    def askMove(self) -> str:
        return input(f"{self.__name} ({'Blanc' if self.__color == 0 else 'Noir'}), entrez votre coup: ")


class AIPlayer(Player):
    def __init__(self, color: int):
        super().__init__("AI", color)

    def askMove(self) -> str:
        import random
        cols = "abcdefgh"
        piece_ids = ["K", "Q", "B", "N", "R", "P"]
        return f"{random.choice(piece_ids)}{random.choice(cols)}{random.randint(1,8)} {random.choice(cols)}{random.randint(1,8)}"
