from board import Board
from player import Player, AIPlayer
from position import Position
import json
import os

class Chess:
    def __init__(self):
        self.__board = Board()
        self.__players = []
        self.__currentPlayer = None

    def getBoard(self):
        return self.__board

    def initPlayers(self):
        for i, color in enumerate([0, 1]):
            name = input(f"Nom du joueur {i+1} (entrez 'AI' pour un joueur automatique): ")
            self.__players.append(AIPlayer(color) if name == "AI" else Player(name, color))
        self.__currentPlayer = self.__players[0]

    def displayBoard(self):
        self.__board.display()

    def _parseMove(self, move: str):
        parts = move.strip().split()
        if len(parts) != 2:
            return None
        origin, destination = parts
        if len(origin) < 3 or len(destination) < 2:
            return None
        piece_id = origin[0].upper()
        from_pos = Position(origin[1].lower(), int(origin[2:]))
        to_pos = Position(destination[0].lower(), int(destination[1:]))
        if not from_pos.isInsideBoard() or not to_pos.isInsideBoard():
            return None
        return piece_id, from_pos, to_pos

    def isValidMove(self, move: str) -> bool:
        parsed = self._parseMove(move)
        if parsed is None or self.__currentPlayer is None:
            return False
        piece_id, from_pos, to_pos = parsed
        piece = self.__board.getPiece(from_pos)
        if piece is None:
            return False
        if piece.getColor() != self.__currentPlayer.getColor():
            return False
        if str(piece) != piece_id:
            return False
        return piece.isValidMove(to_pos, self.__board)

    def isCheckMate(self) -> bool:
        return False

    def updateBoard(self, move: str):
        parsed = self._parseMove(move)
        if parsed is None:
            return
        _, from_pos, to_pos = parsed
        self.__board.movePiece(from_pos, to_pos)

    def switchPlayer(self):
        if self.__currentPlayer == self.__players[0]:
            self.__currentPlayer = self.__players[1]
        else:
            self.__currentPlayer = self.__players[0]

    def saveGame(self, filename: str = "save/savegame.json"):
        data = {
            "current_player_color": None if self.__currentPlayer is None else self.__currentPlayer.getColor(),
            "players": [
                {"name": player.getName(), "color": player.getColor(), "ai": isinstance(player, AIPlayer)}
                for player in self.__players
            ],
            "board": self.__board.serialize(),
        }
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def loadGame(self, filename: str = "save/savegame.json"):
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.__players = []
        for p in data["players"]:
            self.__players.append(AIPlayer(p["color"]) if p.get("ai") else Player(p["name"], p["color"]))
        self.__board.loadFromData(data["board"])
        current_color = data.get("current_player_color", 0)
        self.__currentPlayer = next((p for p in self.__players if p.getColor() == current_color), None)

    def play(self):
        self.initPlayers()
        while not self.isCheckMate():
            self.displayBoard()
            move = ""
            while not self.isValidMove(move):
                move = self.__currentPlayer.askMove()
            self.updateBoard(move)
            self.switchPlayer()
        print("Échec et mat !")
