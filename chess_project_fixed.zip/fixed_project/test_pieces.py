import unittest
from position import Position
from board import Board
from pieces.knight import Knight
from pieces.pawn import Pawn

class TestPieces(unittest.TestCase):
    def setUp(self):
        self.board = Board()

    def test_knight_str(self):
        knight = Knight(Position("b", 1), 0)
        self.assertEqual(str(knight), "N")

    def test_knight_valid_move(self):
        knight = Knight(Position("b", 1), 0)
        self.assertTrue(knight.isValidMove(Position("c", 3), self.board))

    def test_pawn_one_step(self):
        pawn = Pawn(Position("a", 2), 0)
        self.assertTrue(pawn.isValidMove(Position("a", 3), self.board))

if __name__ == "__main__":
    unittest.main()
