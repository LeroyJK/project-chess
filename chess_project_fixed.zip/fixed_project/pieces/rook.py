from piece import Piece
from position import Position

class Rook(Piece):
    def __init__(self, position: Position, color: int):
        super().__init__(position, color)

    def isValidMove(self, newPosition: Position, board) -> bool:
        current = self.getPosition()
        if not newPosition.isInsideBoard() or newPosition == current:
            return False
        if self._target_has_same_color(newPosition, board):
            return False
        if current.getColumn() != newPosition.getColumn() and current.getRow() != newPosition.getRow():
            return False
        return board.isPathClear(current, newPosition)

    def __str__(self):
        return "R"
