from piece import Piece
from position import Position

class Pawn(Piece):
    def __init__(self, position: Position, color: int):
        super().__init__(position, color)

    def isValidMove(self, newPosition: Position, board) -> bool:
        current = self.getPosition()
        if not newPosition.isInsideBoard() or newPosition == current:
            return False

        direction = 1 if self.getColor() == 0 else -1
        start_row = 2 if self.getColor() == 0 else 7
        dc = ord(newPosition.getColumn()) - ord(current.getColumn())
        dr = newPosition.getRow() - current.getRow()
        target = board.getPiece(newPosition)

        # avancer d'une case
        if dc == 0 and dr == direction and target is None:
            return True

        # avancer de deux cases au départ
        if dc == 0 and dr == 2 * direction and current.getRow() == start_row and target is None:
            intermediate = Position(current.getColumn(), current.getRow() + direction)
            return board.getPiece(intermediate) is None

        # capture en diagonale
        if abs(dc) == 1 and dr == direction and target is not None and target.getColor() != self.getColor():
            return True

        return False

    def __str__(self):
        return "P"
