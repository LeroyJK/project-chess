from piece import Piece
from position import Position

class Queen(Piece):
    def __init__(self, position: Position, color: int):
        super().__init__(position, color)

    def isValidMove(self, newPosition: Position, board) -> bool:
        current = self.getPosition()
        if not newPosition.isInsideBoard() or newPosition == current:
            return False
        if self._target_has_same_color(newPosition, board):
            return False
        dc = abs(ord(newPosition.getColumn()) - ord(current.getColumn()))
        dr = abs(newPosition.getRow() - current.getRow())
        straight = current.getColumn() == newPosition.getColumn() or current.getRow() == newPosition.getRow()
        diagonal = dc == dr
        if not (straight or diagonal):
            return False
        return board.isPathClear(current, newPosition)

    def __str__(self):
        return "Q"
