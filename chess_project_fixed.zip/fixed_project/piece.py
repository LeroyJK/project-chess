from abc import ABC, abstractmethod
from position import Position

class Piece(ABC):
    def __init__(self, position: Position, color: int):
        self.__position = position
        self.__color = color

    def getPosition(self):
        return self.__position

    def getColor(self):
        return self.__color

    def setPosition(self, position: Position):
        self.__position = position

    def _target_has_same_color(self, newPosition: Position, board) -> bool:
        target = board.getPiece(newPosition)
        return target is not None and target.getColor() == self.getColor()

    @abstractmethod
    def isValidMove(self, newPosition: Position, board) -> bool:
        pass

    @abstractmethod
    def __str__(self) -> str:
        pass
