from position import Position
from pieces.king import King
from pieces.queen import Queen
from pieces.bishop import Bishop
from pieces.knight import Knight
from pieces.rook import Rook
from pieces.pawn import Pawn

class Board:
    def __init__(self):
        self.__grid = {}
        self.__initBoard()

    def __initBoard(self):
        self.__grid.clear()
        self.__grid["a1"] = Rook(Position("a", 1), 0)
        self.__grid["b1"] = Knight(Position("b", 1), 0)
        self.__grid["c1"] = Bishop(Position("c", 1), 0)
        self.__grid["d1"] = Queen(Position("d", 1), 0)
        self.__grid["e1"] = King(Position("e", 1), 0)
        self.__grid["f1"] = Bishop(Position("f", 1), 0)
        self.__grid["g1"] = Knight(Position("g", 1), 0)
        self.__grid["h1"] = Rook(Position("h", 1), 0)
        for col in "abcdefgh":
            self.__grid[f"{col}2"] = Pawn(Position(col, 2), 0)

        self.__grid["a8"] = Rook(Position("a", 8), 1)
        self.__grid["b8"] = Knight(Position("b", 8), 1)
        self.__grid["c8"] = Bishop(Position("c", 8), 1)
        self.__grid["d8"] = Queen(Position("d", 8), 1)
        self.__grid["e8"] = King(Position("e", 8), 1)
        self.__grid["f8"] = Bishop(Position("f", 8), 1)
        self.__grid["g8"] = Knight(Position("g", 8), 1)
        self.__grid["h8"] = Rook(Position("h", 8), 1)
        for col in "abcdefgh":
            self.__grid[f"{col}7"] = Pawn(Position(col, 7), 1)

    def getPosition(self, piece):
        for p in self.__grid.values():
            if p == piece:
                return p.getPosition()
        return None

    def getPiece(self, position: Position):
        return self.__grid.get(str(position), None)

    def setPiece(self, position: Position, piece):
        if piece is not None:
            piece.setPosition(position)
            self.__grid[str(position)] = piece

    def removePiece(self, position: Position):
        self.__grid.pop(str(position), None)

    def movePiece(self, fromPosition: Position, toPosition: Position):
        piece = self.getPiece(fromPosition)
        if piece is None:
            return False
        self.removePiece(toPosition)
        self.removePiece(fromPosition)
        piece.setPosition(toPosition)
        self.setPiece(toPosition, piece)
        return True

    def isPathClear(self, start: Position, end: Position) -> bool:
        col_step = 0
        if ord(end.getColumn()) > ord(start.getColumn()):
            col_step = 1
        elif ord(end.getColumn()) < ord(start.getColumn()):
            col_step = -1

        row_step = 0
        if end.getRow() > start.getRow():
            row_step = 1
        elif end.getRow() < start.getRow():
            row_step = -1

        col = ord(start.getColumn()) + col_step
        row = start.getRow() + row_step

        while col != ord(end.getColumn()) or row != end.getRow():
            if self.getPiece(Position(chr(col), row)) is not None:
                return False
            col += col_step
            row += row_step
        return True

    def getPiecesByColor(self, color: int):
        return [piece for piece in self.__grid.values() if piece.getColor() == color]

    def serialize(self):
        return [
            {
                "type": piece.__class__.__name__,
                "color": piece.getColor(),
                "position": str(piece.getPosition()),
            }
            for piece in self.__grid.values()
        ]

    def loadFromData(self, pieces_data):
        mapping = {
            "King": King,
            "Queen": Queen,
            "Bishop": Bishop,
            "Knight": Knight,
            "Rook": Rook,
            "Pawn": Pawn,
        }
        self.__grid.clear()
        for item in pieces_data:
            pos = Position(item["position"][0], int(item["position"][1:]))
            cls = mapping[item["type"]]
            self.__grid[item["position"]] = cls(pos, item["color"])

    def display(self):
        print("  a b c d e f g h")
        for row in range(8, 0, -1):
            line = f"{row} "
            for col in "abcdefgh":
                piece = self.__grid.get(f"{col}{row}")
                if piece is None:
                    line += ". "
                else:
                    symbol = str(piece)
                    line += (symbol.upper() if piece.getColor() == 0 else symbol.lower()) + " "
            print(line)
        print()
