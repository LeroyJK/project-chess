import unittest
from board import Board
from position import Position

class TestBoard(unittest.TestCase):
    def setUp(self):
        self.board = Board()

    def test_initial_piece_at_e1(self):
        piece = self.board.getPiece(Position("e", 1))
        self.assertIsNotNone(piece)
        self.assertEqual(str(piece), "K")

    def test_empty_square(self):
        self.assertIsNone(self.board.getPiece(Position("e", 4)))

if __name__ == "__main__":
    unittest.main()
